;

<?php $__env->startSection('content'); ?>
<section>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-8">
                <h1>CRUD LARAVEL</h1>
                <a href="<?php echo e(url('create')); ?>" class="btn btn-primary">+ Tambah Mahasiswa</a>
            </div>

            <div class="col-lg-8">
                <table class="table-bordered mt-5">
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Alamat</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataMahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dataMahasiswa->id); ?></td>
                        <td><?php echo e($dataMahasiswa->nama); ?></td>
                        <td><?php echo e($dataMahasiswa->nim); ?></td>
                        <td><?php echo e($dataMahasiswa->alamat); ?></td>
                        <td><a href="<?php echo e(url('/show/'.$dataMahasiswa->id)); ?>" class="btn btn-warning">Edit</a>
                        <a href="<?php echo e(url('/destroy/'.$dataMahasiswa->id)); ?>" class="btn btn-danger">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-Project\crud-laravel\resources\views/index.blade.php ENDPATH**/ ?>